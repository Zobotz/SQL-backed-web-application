const express = require('express');
const ejs = require('ejs');
const util = require('util');
const mysql = require('mysql2');
const bodyParser = require('body-parser');


/**
 * The following constants with your MySQL connection properties
 * You should only need to change the password
 */

const PORT = 8000;
const DB_HOST = 'localhost';
const DB_USER = 'root';
const DB_PASSWORD = 'ZM9DCwFVtQ';
const DB_NAME = 'coursework';
const DB_PORT = 3306;

/**
 * DO NOT CHANGE ANYTHING BELOW THIS LINE UP TO THE NEXT COMMENT
 */
var connection = mysql.createConnection({
	host: DB_HOST,
	user: DB_USER,
	password: DB_PASSWORD,
	database: DB_NAME,
	port: DB_PORT
});

connection.query = util.promisify(connection.query).bind(connection);

connection.connect(function (err) {
	if (err) {
		console.error('error connecting: ' + err.stack);
		console.log('Please make sure you have updated the password in the index.js file. Also, ensure you have run db_setup.sql to create the database and tables.');
		return;
	}
	console.log('Connected to the Database');
});


const app = express();

app.set('view engine', 'ejs');
app.use(express.static('public'));
app.use(bodyParser.urlencoded({ extended: false }));

/**
 * YOU CAN CHANGE THE CODE BELOW THIS LINE
 */

// Add your code here

app.get('/', async (req, res) => {

	const TotalCourses = await connection.query(
		'SELECT COUNT(*) as count FROM Course'
	);
	const TotalEnrollments = await connection.query(
		'SELECT SUM(Crs_Enrollment) as sum FROM Course'
	);
	const AverageEnrollments = await connection.query(
		'SELECT AVG(Crs_Enrollment) as avg FROM Course'
	);
	const HighestEnrollments = await connection.query(
		'SELECT Crs_Title as high FROM Course WHERE Crs_Enrollment = (SELECT MAX(Crs_Enrollment) FROM Course)'
	);
	const LowestEnrollments = await connection.query(		
		'SELECT Crs_Title as low FROM Course WHERE Crs_Enrollment = (SELECT MIN(Crs_Enrollment) FROM Course)'
	);

	res.render("index", {
		TotalCourses: TotalCourses[0].count,
		TotalEnrollments: TotalEnrollments[0].sum,
		AverageEnrollments: AverageEnrollments[0].avg,
		HighestEnrollments: HighestEnrollments[0].high,
		LowestEnrollments: LowestEnrollments[0].low
	});

	
});

app.get('/courses', async (req, res) => {
	const allCourse = await connection.query(
		'SELECT * FROM Course'
	)
	res.render("courses", {
		allCourse: allCourse
	});
});

app.get('/edit-course/:id', async (req, res) => {
	const course = await connection.query(
		'SELECT * FROM Course WHERE Crs_Code = ?',
		[req.params.id]
	);
	var message = "";
	res.render('edit', {
		course: course, //passes the row in the database
		message: message
	}
	);
});

app.get('/create-course', async (req, res) => {
	const course = await connection.query(
		'SELECT * FROM Course'
	)
	const message = "";
	res.render('create', {
		course: course,
		message: message
	});
});

app.post('/edit-course/:id', async (req, res) => {
	const title = req.body.Crs_Title;
	const enrollment = req.body.Crs_Enrollment;
	const courseCode = req.params.id;

	const course = await connection.query(
		'SELECT * FROM Course WHERE Crs_Code = ?',
		[courseCode]
	);
	var message = "";

	if (title.length < 10 || title.length > 250 || enrollment < 0 || enrollment > 10000) {
			message = "error - invalid input";
		} else {
		try {
			await connection.query("UPDATE Course SET Crs_Title = ? WHERE Crs_Code = ?",
			[title, courseCode]);
			await connection.query("UPDATE Course SET Crs_Enrollment = ? WHERE Crs_Code = ?",
				[enrollment, courseCode]);
			message = "updated! refresh to see values";
		} catch(error) {
			console.log(error);
			message = "error";
		}
	}
	res.render('edit', {
		course: course,
		message: message
	});
});

app.post('/create-course', async (req, res) => {
	const title = req.body.Crs_Title;
	const enrollment = req.body.Crs_Enrollment;
	const code = req.body.Crs_Code;
	const courseCode = req.params.id;

	const course = await connection.query(
		'SELECT * FROM Course WHERE Crs_Code = ?',
		[courseCode]
	);
	var message = "";

	if (title.length < 10 || title.length > 250 || enrollment < 0 || enrollment > 10000 || code == 0) {
		message = "error - invalid input";
		} else {
		try {
			await connection.query("INSERT INTO Course VALUES (?, ?, ?)",
				[code, title, enrollment]);
				message = "updated!";
		} catch(error) {
			console.log(error);
			message = "error";
		}
	}
	res.render('create', {
		course: course,
		message: message
	});
});


// delete page used to remove extra webpages once testing was complete

app.get('/delete-course/4', async (req, res) => {
	const course = await connection.query(
		'SELECT * FROM Course WHERE Crs_Code = ?',
		[req.params.id]
	)
	res.render('delete', {
	});
});
app.post('/delete-course/4', async (req, res) => {
	await connection.query("DELETE FROM Course WHERE Crs_Code = 4")
});


/**
 * DON'T CHANGE ANYTHING BELOW THIS LINE
 */

app.listen(PORT, () => {

	console.log(`Server is running on port http://localhost:${PORT}`);

});



exports.app = app;